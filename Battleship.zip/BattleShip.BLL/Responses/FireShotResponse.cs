﻿namespace BattleShip.BLL.Responses
{
    public class FireShotResponse
    {
        public ShotStatus ShotStatus { get; set; }
        public string ShipImpacted { get; set; }
    }
}
