﻿namespace BattleShip.BLL.Responses
{
    public enum ShotStatus
    {
        Invalid,
        Duplicate,
        Miss,
        Hit,
        HitAndSunk,
        Victory
    }
}
