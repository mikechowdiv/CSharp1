﻿namespace BattleShip.BLL.Ships
{
    public enum ShipType
    {
        Destroyer,
        Submarine,
        Cruiser,
        Battleship,
        Carrier
    }
}
